---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

### Describe the bug
<!-- A clear and concise description of what the bug is. -->

**Code**:
<!-- The code you run which reflect the bug. -->

**Wrong display or Error traceback**:
<!-- the wrong display result of the code you run, or the error Traceback -->

### Additional context
<!-- Add any other context about the problem here. -->
